from mazegen import MazeGenerator

gen = MazeGenerator(10, 10, (0, 0), (9, 9), seed=1)
gen.generate()
print(gen.maze)
gen.solve()
print(gen.solution)
gen.generate()
