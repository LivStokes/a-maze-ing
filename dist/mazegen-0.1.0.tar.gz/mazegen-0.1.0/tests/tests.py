from config import MazeConfig
from grid import Cell
from dataclasses import asdict

config = MazeConfig(30, 30, Cell(0, 0), Cell(1, 1), "output.txt", True, None, "backtracking", True)
print(asdict(config))
