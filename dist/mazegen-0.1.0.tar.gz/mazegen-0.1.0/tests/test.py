from itertools import cycle
from pyfiglet import figlet_format

test = cycle([1, 2, 3, 4, 5])
print(next(test))
print(f"{figlet_format(str(next(test)))}")
print(f"{figlet_format(str(next(test)))}")
