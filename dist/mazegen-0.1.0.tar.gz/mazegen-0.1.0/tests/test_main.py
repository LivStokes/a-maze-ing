from time import sleep
import curses
import sys


def main(stdscr: curses.window):
    # sys.setrecursionlimit(20000)
    curses.curs_set(0)
    curses.noecho()
    curses.cbreak()
    curses.start_color()
    curses.use_default_colors()
    stdscr.refresh()
    from maze_generators import Maze
    from print_maze import MazePrint
    from color_palletes import colors

    # sleep(3)
    gene = Maze((120, 120))
    gene.backtracking()
    display = MazePrint(gene, stdscr)
    display.create_ascii()
    display.display_all(colors.next_pallete())
    stdscr.refresh()
    while (True):
        sleep(1)
        display.display_all(colors.next_pallete())
        stdscr.refresh()
    # stdscr.refresh()
    # while (key := stdscr.getch()) != "q":
    #     # print(key)
    #     machine.handler(key)
    #     # stdscr.refresh


if __name__ == '__main__':
    curses.wrapper(main)
